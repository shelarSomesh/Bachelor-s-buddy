let totalIncome = 0;
let totalExpenses = 0;

function addIncome() {
  const incomeInput = document.getElementById("incomeAmount");
  const income = parseFloat(incomeInput.value);

  if (!isNaN(income) && income > 0) {
    totalIncome += income;
    updateUI();
    incomeInput.value = "";
  } else {
    alert("Please enter a valid income amount.");
  }
}

function addExpense() {
  const descInput = document.getElementById("expenseDesc");
  const amountInput = document.getElementById("expenseAmount");
  const desc = descInput.value.trim();
  const amount = parseFloat(amountInput.value);

  if (desc && !isNaN(amount) && amount > 0) {
    totalExpenses += amount;
    const li = document.createElement("li");
    li.textContent = `${desc} - ₹${amount}`;
    document.getElementById("expenseList").appendChild(li);
    updateUI();
    descInput.value = "";
    amountInput.value = "";
  } else {
    alert("Enter valid description and amount.");
  }
}

function updateUI() {
  document.getElementById("totalIncome").textContent = totalIncome;
  document.getElementById("totalExpenses").textContent = totalExpenses;
  document.getElementById("balance").textContent = totalIncome - totalExpenses;
}
