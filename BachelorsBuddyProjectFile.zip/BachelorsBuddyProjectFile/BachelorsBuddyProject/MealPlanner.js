function createListItem(text) {
  const li = document.createElement("li");
  li.textContent = text;

  const removeBtn = document.createElement("button");
  removeBtn.textContent = "×";
  removeBtn.className = "remove-btn";
  removeBtn.onclick = function () {
    li.remove();
    updateMealStorage();
  };

  li.appendChild(removeBtn);
  document.getElementById("mealList").appendChild(li);
}

function addMeal() {
  const input = document.getElementById("mealInput");
  const meal = input.value.trim();
  if (meal !== "") {
    createListItem(meal);
    input.value = "";
    updateMealStorage();
  }
}

function updateMealStorage() {
  const meals = [];
  document.querySelectorAll("#mealList li").forEach(li => {
    const text = li.childNodes[0].textContent.trim();
    if (text) meals.push(text);
  });
  localStorage.setItem("meals", JSON.stringify(meals));
}

function loadMeals() {
  const meals = JSON.parse(localStorage.getItem("meals")) || [];
  meals.forEach(meal => createListItem(meal));
}

window.onload = loadMeals;
// options
const mealData = {
  breakfast: [
    "Poha", "Upma", "Idli", "Dosa", "Pancakes", "Paratha", "Omelette",
    "Toast", "Cornflakes", "Sandwich", "Fruit Salad", "Muesli", "Porridge"
  ],
  lunch: [
    "Dal Rice", "Paneer Butter Masala", "Chole Bhature", "Veg Biryani",
    "Roti Sabzi", "Kadhi Chawal", "Rajma Rice", "Pulao", "Palak Paneer",
    "Aloo Gobi", "Bhindi Masala"
  ],
  dinner: [
    "Chapati Sabzi", "Khichdi", "Daliya", "Maggi", "Soup with Toast",
    "Curd Rice", "Mix Veg", "Dal Tadka", "Veg Sandwich", "Roti and Daal"
  ]
};

function showOptions(mealType) {
  const optionsDiv = document.getElementById("mealOptions");
  optionsDiv.innerHTML = ""; // clear previous

  mealData[mealType].forEach(meal => {
    const btn = document.createElement("button");
    btn.textContent = meal;
    btn.onclick = () => addMeal(`${meal} (${mealType})`);
    optionsDiv.appendChild(btn);
  });
}

function createListItem(text) {
  const li = document.createElement("li");
  li.textContent = text;

  const removeBtn = document.createElement("button");
  removeBtn.textContent = "×";
  removeBtn.className = "remove-btn";
  removeBtn.onclick = function () {
    li.remove();
    updateMealStorage();
  };

  li.appendChild(removeBtn);
  document.getElementById("mealList").appendChild(li);
}

function addMeal(meal) {
  createListItem(meal);
  updateMealStorage();
}

function updateMealStorage() {
  const meals = [];
  document.querySelectorAll("#mealList li").forEach(li => {
    const text = li.childNodes[0].textContent.trim();
    if (text) meals.push(text);
  });
  localStorage.setItem("meals", JSON.stringify(meals));
}

function loadMeals() {
  const meals = JSON.parse(localStorage.getItem("meals")) || [];
  meals.forEach(meal => createListItem(meal));
}

window.onload = loadMeals;
