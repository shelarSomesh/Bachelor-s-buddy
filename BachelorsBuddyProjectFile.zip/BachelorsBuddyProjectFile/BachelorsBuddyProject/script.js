
document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("loginForm");

  form.addEventListener("submit", function (e) {
    e.preventDefault(); 

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;


    if (username === "admin" && password === "1234") {
      
      window.location.href = "dashboard.html";
    } else {
      alert("Invalid username or password.");
    }
  });
});
