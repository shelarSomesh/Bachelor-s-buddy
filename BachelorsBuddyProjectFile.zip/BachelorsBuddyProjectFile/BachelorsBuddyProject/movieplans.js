const movieData = {
  bollywood: ["3 Idiots", "Shershaah", "Zindagi Na Milegi Dobara", "Pathaan", "OMG 2"],
  hollywood: ["Inception", "The Dark Knight", "Interstellar", "Avengers: Endgame", "Oppenheimer"],
  tollywood: ["Vikram", "Leo", "Bahubali", "kaithi", "Sita Ramam","Thug Life"],
  marathi: ["Sairat", "Timepass", "Natsamrat", "Jhimma", "Ved"],
  bhojpuri: ["Sasura Bada Paisawala", "Nirahua Hindustani", "Gadar", "Mehandi Laga Ke Rakhna"],
  punjabi: ["Carry On Jatta", "Qismat", "Sufna", "Jatt & Juliet", "Shooter"],
  anime: ["Your Name", "Naruto", "Demon Slayer", "Attack on Titan", "Spirited Away"]
};

function showMovies() {
  const category = document.getElementById("category").value;
  const movieListDiv = document.getElementById("movieList");
  movieListDiv.innerHTML = "";

  if (category && movieData[category]) {
    movieData[category].forEach(movie => {
      const btn = document.createElement("button");
      btn.textContent = movie;
      btn.onclick = () => addToPlan(movie);
      movieListDiv.appendChild(btn);
    });
  }
}

function addToPlan(movie) {
  const myPlan = document.getElementById("myPlan");
  const li = document.createElement("li");
  li.textContent = movie;
  myPlan.appendChild(li);
}
